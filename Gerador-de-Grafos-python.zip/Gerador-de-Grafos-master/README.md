# Gerador-de-Grafos
Execute "python gerar.py"


AVISO!
Não gere um grafo completo de 10000 vértices, nem a pau.
Haverá muita alocação de memória.
